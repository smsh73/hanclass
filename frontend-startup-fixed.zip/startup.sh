#!/bin/sh
cd /home/site/wwwroot
export NODE_ENV=production
export PORT=${PORT:-8080}

echo "=== Frontend Startup Script ==="
echo "Working directory: $(pwd)"
echo "Files in directory:"
ls -la | head -10

echo ""
echo "Installing dependencies..."
npm install --production=false --legacy-peer-deps

echo ""
echo "Building Next.js..."
npm run build

if [ $? -ne 0 ]; then
  echo "Build failed, checking if .next exists..."
  if [ -d ".next" ]; then
    echo ".next directory exists, continuing..."
  else
    echo "Build failed and .next not found. Exiting."
    exit 1
  fi
fi

echo ""
echo "Starting Next.js server on port $PORT..."
exec npm start

