#!/bin/sh
cd /home/site/wwwroot
export NODE_ENV=production
export PORT=${PORT:-8080}
echo "Working directory: $(pwd)"
echo "Installing dependencies..."
npm install
echo "Building Next.js..."
npm run build || echo "Build warning, continuing..."
echo "Starting server on port $PORT..."
exec npm start

