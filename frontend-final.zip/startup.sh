#!/bin/sh
cd /home/site/wwwroot
export NODE_ENV=production
export PORT=${PORT:-8080}
echo "Working directory: $(pwd)"
echo "Installing dependencies..."
npm install --production=false
echo "Building Next.js..."
if ! npm run build; then
  echo "Build failed!"
  exit 1
fi
echo "Starting server on port $PORT..."
exec npm start

