#!/bin/sh
cd /home/site/wwwroot
export NODE_ENV=production
export PORT=${PORT:-8080}
export HOSTNAME=0.0.0.0

echo "=== Frontend Startup Script ==="
echo "Working directory: $(pwd)"
echo "Files in directory:"
ls -la | head -20

# Install dependencies
echo "Installing dependencies..."
npm install --production=false --legacy-peer-deps || {
  echo "npm install failed!"
  exit 1
}

# Build Next.js
echo "Building Next.js..."
npm run build || {
  echo "Build failed!"
  exit 1
}

# Check if standalone build exists
if [ -d ".next/standalone" ]; then
  echo "Standalone build found. Setting up..."
  # Copy static files to standalone directory
  if [ -d ".next/static" ]; then
    cp -r .next/static .next/standalone/.next/static 2>/dev/null || true
  fi
  if [ -d "public" ]; then
    cp -r public .next/standalone/public 2>/dev/null || true
  fi
  cd .next/standalone
  echo "Starting standalone server from $(pwd)..."
  exec node server.js
else
  echo "Standalone build not found. Using npm start..."
  exec npm start
fi

