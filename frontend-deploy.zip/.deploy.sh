#!/bin/bash
# Next.js 배포 스크립트

cd frontend
npm install
npm run build
cd ..

