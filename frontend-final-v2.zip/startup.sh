#!/bin/sh
cd /home/site/wwwroot
export NODE_ENV=production
export PORT=${PORT:-8080}

echo "=== Starting Frontend ==="
echo "Working directory: $(pwd)"

if [ ! -f "package.json" ]; then
  echo "ERROR: package.json not found!"
  exit 1
fi

# Check if already built
if [ ! -d ".next" ]; then
  echo "Installing dependencies..."
  npm install --production=false
  
  echo "Building Next.js..."
  npm run build
  
  if [ ! -d ".next" ]; then
    echo "ERROR: Build failed - .next directory not found"
    exit 1
  fi
else
  echo ".next directory exists, skipping build"
  # Still install dependencies in case they're missing
  npm install --production=false
fi

echo "Starting Next.js server on port $PORT..."
exec npm start

