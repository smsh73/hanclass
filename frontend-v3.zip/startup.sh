#!/bin/sh
cd /home/site/wwwroot
export NODE_ENV=production
export PORT=${PORT:-8080}

echo "=== Frontend Startup Script ==="
echo "Working directory: $(pwd)"

# Check if .next exists (pre-built)
if [ ! -d ".next" ]; then
  echo "Installing dependencies..."
  npm install --production=false
  
  echo "Building Next.js..."
  npm run build || {
    echo "Build failed!"
    exit 1
  }
fi

echo "Starting Next.js server on port $PORT..."
exec npm start

