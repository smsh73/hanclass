#!/bin/sh
cd /home/site/wwwroot
echo "Current directory: $(pwd)"
echo "Listing files:"
ls -la
echo "Checking for package.json..."
if [ ! -f "package.json" ]; then
  echo "ERROR: package.json not found!"
  echo "Files in current directory:"
  ls -la
  exit 1
fi
echo "package.json found. Installing dependencies..."
npm install --production=false
echo "Building Next.js application..."
npm run build
if [ $? -ne 0 ]; then
  echo "Build failed, but checking if .next directory exists..."
  if [ -d ".next" ]; then
    echo ".next directory exists, continuing..."
  else
    echo "Build failed and .next directory not found. Exiting."
    exit 1
  fi
fi
echo "Starting Next.js application on port ${PORT:-8080}..."
exec npm start

